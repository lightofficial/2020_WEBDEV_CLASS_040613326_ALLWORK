<?php
    $search_name = $_REQUEST["keyword"];
    header("location:index.php?shop_name=".$search_name."");
?>