<?php
    $search_name = $_REQUEST["keyword"];
    header("location:index_2.php?food_name=".$search_name."");
?>